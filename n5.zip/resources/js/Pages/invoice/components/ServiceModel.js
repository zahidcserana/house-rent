const ServiceModel = {
    search: {
        customer_id: '',
        status: 'unpaid',
    }
}

export default ServiceModel