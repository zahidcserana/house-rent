# House Rent Management

## Condition

- Role wise list fetching
- payment entry & history
- get customer dues list
- dashboard: last 5 payment history
- top 5 invoices
- export invoices & payments
- list of unrented flats
- filter options for all
